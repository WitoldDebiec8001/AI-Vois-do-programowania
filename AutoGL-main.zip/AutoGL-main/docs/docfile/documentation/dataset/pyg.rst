PyTorch Geometric Dataset
==========================

.. automodule:: autogl.datasets
   :members:
