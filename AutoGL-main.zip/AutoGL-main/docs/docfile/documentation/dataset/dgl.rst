Deep Graph Library Dataset
==========================

.. automodule:: autogl.datasets
   :members:
