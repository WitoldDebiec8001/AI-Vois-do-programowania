.. _solver documentation:

autogl.solver
=============

.. automodule:: autogl.solver
    :members: