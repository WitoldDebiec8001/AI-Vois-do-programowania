PyTorch Geometric Backend
=========================

Models
~~~~~~

.. automodule:: autogl.module.model.pyg
    :members:

Encoders
~~~~~~~~

.. automodule:: autogl.module.model.encoders
    :members:

Decoders
~~~~~~~~

.. automodule:: autogl.module.model.decoders
    :members:

