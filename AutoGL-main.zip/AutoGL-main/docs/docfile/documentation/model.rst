.. _model documentation:

autogl.module.model
-------------------

.. toctree::

    model/dgl.rst
    model/pyg.rst
