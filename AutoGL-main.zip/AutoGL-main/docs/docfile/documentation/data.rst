.. _data documentation:

autogl.data
===========

.. automodule:: autogl.data
   :members: