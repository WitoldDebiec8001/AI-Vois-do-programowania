.. _neural architecture search:

autogl.module.nas
-----------------

.. automodule:: autogl.module.nas.algorithm
    :members:

.. automodule:: autogl.module.nas.space
    :members:

.. automodule:: autogl.module.nas.estimator
    :members:
