.. _feature documentation:

autogl.module.feature
=====================

We support feature engineering for both PyTorch Geometric and Deep Deep Graph Library backend.

.. automodule:: autogl.module.feature
	:members:
