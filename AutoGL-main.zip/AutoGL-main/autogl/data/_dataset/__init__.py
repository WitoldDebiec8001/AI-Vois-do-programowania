from ._dataset import Dataset, InMemoryDataset
from ._in_memory_static_graph_set import InMemoryStaticGraphSet
