from .gcn_conv import GCNConv

__all__ = [
    'GCNConv'
]

classes = __all__
