from django.test import TestCase

from suggestion.early_stop_algorithm.abstract_early_stop import (
    AbstractEarlyStopAlgorithm,
)


class RandomSearchAlgorithmTest(TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_init(self):
        pass

        # abstractEarlyStopAlgorithm = AbstractEarlyStopAlgorithm()
        # self.assertEqual(abstractEarlyStopAlgorithm.__class__, AbstractEarlyStopAlgorithm)
